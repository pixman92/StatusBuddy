//functions to show/hide divs
function hide(id){
    document.getElementById(id).classList.add("hidden");
    
}
function show(id){
    document.getElementById(id).classList.remove("hidden");

}